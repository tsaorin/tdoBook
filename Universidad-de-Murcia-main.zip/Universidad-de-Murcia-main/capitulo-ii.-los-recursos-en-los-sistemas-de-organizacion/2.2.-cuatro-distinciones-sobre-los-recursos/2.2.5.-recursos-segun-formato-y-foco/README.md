# 2.2.5. Recursos según formato y foco

