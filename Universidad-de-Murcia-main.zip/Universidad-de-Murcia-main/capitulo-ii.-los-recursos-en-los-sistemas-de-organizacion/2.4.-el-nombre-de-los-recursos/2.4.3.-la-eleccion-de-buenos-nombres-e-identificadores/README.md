# 2.4.3. La elección de buenos nombres e identificadores

