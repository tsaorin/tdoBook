# 2.4. El nombre de los recursos

