# 2.5. Los recursos y el paso del tiempo

