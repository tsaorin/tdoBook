# 2.3. La identidad de los recursos

